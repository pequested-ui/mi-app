﻿# Hamlib Launcher v1.1

Hamlib Launcher provides a Tkinter user interface for configuring and launching `rigctld.exe` on Windows. It helps radio operators start the daemon with the required serial and network parameters while keeping the console hidden and still allowing Ctrl+C shutdown from the GUI.

## Features
- Discover serial ports using `pyserial`.
- Query `rigctl.exe -l` to list supported radio models and persist the selection in `config.json`.
- Launch `rigctld` with its console hidden but still able to receive Ctrl+C.
- Change the listening IP and TCP port (defaults to `localhost:4532`).
- Gracefully stop `rigctld` when pressing the stop button or closing the window.
- Custom window/taskbar icon through `launcher.ico` and a Windows AppUserModelID.

## Requirements
- Windows 7, 10 or 11 (64-bit).
- Python 3.10+ if running from source.
- Hamlib binaries (`rigctl.exe`, `rigctld.exe`).
- Python packages: `pyserial`, `psutil`.

Install the Python dependencies:

```powershell
python -m pip install -r requirements.txt
```

## Running from source
```powershell
python hamlib_launcher.py
```

Then select the Hamlib folder, serial port, baud rate, radio model, and optionally adjust the listening IP/port before starting `rigctld`. The application stores your last choices in `config.json` next to the executable or script. Remove the file to reset.

## Download
- Ready-to-use builds are published at [acuanticopower.com/hamlib-launcher-rigctld-sin-comandos](https://acuanticopower.com/hamlib-launcher-rigctld-sin-comandos/)

## Building the standalone exe
```powershell
pyinstaller --onefile --noconsole --name "HamlibLauncher" --icon launcher.ico hamlib_launcher.py
```

Add extra resources with `--add-data` if needed. The generated binary is placed in `dist/HamlibLauncher/`.

## Project structure
- `hamlib_launcher.py` - Tkinter UI and process control logic.
- `launcher.ico` - application icon for the window and Windows taskbar.
- `requirements.txt` - runtime dependencies for the script version.
- `CHANGELOG.md`, `CONTRIBUTING.md`, `LICENSE`, `README.md`, `README_EXE.md` - documentation.
- `.gitignore` - ignores build artefacts (`build/`, `dist/`, `__pycache__/`, etc.).

## Versioning
Release history lives in `CHANGELOG.md`. Current version: **1.1**. A packaged build for this release is available via the download link above.

## License
Distributed under the MIT License. See `LICENSE` for details.

## Credits
Created by [Acuantico Power](https://acuanticopower.com).

## Acknowledgements
Special thanks to [Riojanos por la Radio](https://riojanosporlaradio.com) for collaboration and field feedback.
