﻿import tkinter as tk
from tkinter import filedialog, messagebox, ttk
import subprocess
import threading
import os
import sys
import json
import time
import ctypes

import serial.tools.list_ports
import psutil

BASE_DIR = os.path.dirname(sys.executable) if getattr(sys, "frozen", False) else os.path.dirname(__file__)
CONFIG_FILE = os.path.join(BASE_DIR, "config.json")
ICONO_APP = os.path.join(BASE_DIR, "launcher.ico")
APP_USER_MODEL_ID = "HamlibLauncher.App"
VERSION = "1.1"
DEFAULT_TCP_HOST = "localhost"
DEFAULT_TCP_PORT = "4532"

rigctld_process = None
stop_event = threading.Event()


def cargar_config():
    if os.path.exists(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as fh:
                return json.load(fh)
        except Exception:
            pass
    return {}


def guardar_config(data):
    with open(CONFIG_FILE, "w", encoding="utf-8") as fh:
        json.dump(data, fh, indent=4)


def leer_salida(proc):
    for line in iter(proc.stdout.readline, ""):
        if stop_event.is_set():
            break
        text_terminal.insert(tk.END, line)
        text_terminal.see(tk.END)
    proc.stdout.close()


def enviar_ctrl_c(pid):
    kernel32 = ctypes.windll.kernel32
    try:
        kernel32.FreeConsole()
        if not kernel32.AttachConsole(pid):
            return False
        kernel32.SetConsoleCtrlHandler(None, True)
        kernel32.GenerateConsoleCtrlEvent(0, 0)
        time.sleep(1)
        kernel32.FreeConsole()
        kernel32.SetConsoleCtrlHandler(None, False)
        text_terminal.insert(tk.END, "[INFO] Senal Ctrl+C enviada.\n")
        text_terminal.see(tk.END)
        return True
    except Exception as exc:
        text_terminal.insert(tk.END, f"[AVISO] Error Ctrl+C: {exc}\n")
        text_terminal.see(tk.END)
        return False


def detener_rigctld():
    global rigctld_process
    text_terminal.insert(tk.END, "\n[INFO] Deteniendo rigctld...\n")
    text_terminal.see(tk.END)

    if rigctld_process and rigctld_process.poll() is None:
        enviar_ctrl_c(rigctld_process.pid)
        try:
            rigctld_process.wait(timeout=4)
        except subprocess.TimeoutExpired:
            text_terminal.insert(tk.END, "[AVISO] rigctld no respondio, forzando cierre.\n")
            text_terminal.see(tk.END)
            rigctld_process.kill()

    for proc in psutil.process_iter(attrs=["pid", "name"]):
        if "rigctld" in (proc.info["name"] or "").lower():
            try:
                proc.terminate()
            except Exception:
                pass

    rigctld_process = None
    boton_ejecutar.config(text="Ejecutar rigctld", bg="#d9534f")
    estado_label.config(text="rigctld detenido")


def ejecutar_o_detener():
    global rigctld_process

    if rigctld_process and rigctld_process.poll() is None:
        detener_rigctld()
        return

    directorio = entry_directorio.get().strip()
    puerto = combo_puerto.get().strip()
    baudios = combo_baudios.get().strip()
    modelo_nombre = combo_modelo.get().strip()
    tcp_host = entry_tcp_host.get().strip() or DEFAULT_TCP_HOST
    tcp_port = entry_tcp_port.get().strip() or DEFAULT_TCP_PORT

    if not all([directorio, puerto, baudios, modelo_nombre]):
        messagebox.showerror("Error", "Completa todos los campos.")
        return

    if not tcp_port.isdigit():
        messagebox.showerror("Error", "El puerto TCP debe ser numerico.")
        return

    exe_path = os.path.join(directorio, "rigctld.exe")
    modelo_id = modelos_dict.get(modelo_nombre)
    if not (os.path.isfile(exe_path) and modelo_id):
        messagebox.showerror("Error", "No se encontro rigctld.exe o el modelo es invalido.")
        return

    try:
        create_new_console = 0x00000010
        create_new_process_group = 0x00000200
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
        startupinfo.wShowWindow = 0

        comando = [
            exe_path,
            "-m",
            modelo_id,
            "-r",
            puerto,
            "-s",
            baudios,
            "-vvvv",
            f"--port={tcp_port}",
        ]
        if tcp_host and tcp_host.lower() not in {"localhost", "127.0.0.1"}:
            comando.append(f"--address={tcp_host}")

        rigctld_process = subprocess.Popen(
            comando,
            stdout=subprocess.PIPE,
            stderr=subprocess.STDOUT,
            text=True,
            creationflags=create_new_console | create_new_process_group,
            startupinfo=startupinfo,
        )

        stop_event.clear()
        threading.Thread(target=leer_salida, args=(rigctld_process,), daemon=True).start()

        boton_ejecutar.config(text="Detener rigctld", bg="#5cb85c")
        estado_label.config(text=f"rigctld ejecutandose ({tcp_host}:{tcp_port})")
        text_terminal.insert(tk.END, f"[INFO] rigctld iniciado en {puerto} @ {baudios} baudios.\n")
        text_terminal.insert(tk.END, f"[INFO] Escuchando en {tcp_host}:{tcp_port}.\n")
        text_terminal.see(tk.END)

        guardar_config(
            {
                "directorio": directorio,
                "puerto": puerto,
                "baudios": baudios,
                "modelo_nombre": modelo_nombre,
                "tcp_host": tcp_host,
                "tcp_port": tcp_port,
            }
        )

    except Exception as exc:
        messagebox.showerror("Error", f"No se pudo ejecutar rigctld:\n{exc}")


def seleccionar_directorio():
    carpeta = filedialog.askdirectory(title="Selecciona el directorio de Hamlib")
    if carpeta:
        entry_directorio.delete(0, tk.END)
        entry_directorio.insert(0, carpeta)
        actualizar_modelos()


def actualizar_modelos():
    directorio = entry_directorio.get().strip()
    exe_path = os.path.join(directorio, "rigctl.exe")
    if not os.path.isfile(exe_path):
        return
    try:
        salida = subprocess.check_output([exe_path, "-l"], text=True)
        modelos_visibles = []
        modelos_dict.clear()
        for linea in salida.strip().splitlines()[1:]:
            partes = linea.split(None, 2)
            if len(partes) >= 3:
                modelo_id, marca, modelo = partes
                nombre = f"{marca} {modelo}"
                modelos_visibles.append(nombre)
                modelos_dict[nombre] = modelo_id
        combo_modelo["values"] = modelos_visibles
    except Exception as exc:
        messagebox.showerror("Error", f"No se pudo cargar la lista de modelos:\n{exc}")


config = cargar_config()
modelos_dict = {}

try:
    ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(APP_USER_MODEL_ID)
except (AttributeError, OSError):
    pass


def al_cerrar_ventana():
    if rigctld_process and rigctld_process.poll() is None:
        detener_rigctld()
    ventana.destroy()


ventana = tk.Tk()
ventana.protocol("WM_DELETE_WINDOW", al_cerrar_ventana)
ventana.title(f"Hamlib Launcher v{VERSION} - Acuantico Power")
ventana.geometry("760x620")
ventana.resizable(False, False)
if os.path.exists(ICONO_APP):
    try:
        if ICONO_APP.lower().endswith(".ico"):
            ventana.iconbitmap(default=ICONO_APP)
        ventana.iconphoto(True, tk.PhotoImage(file=ICONO_APP))
    except Exception:
        pass

label_dir = tk.Label(ventana, text="Directorio de Hamlib:")
label_dir.pack(pady=5)
frame_dir = tk.Frame(ventana)
frame_dir.pack()
entry_directorio = tk.Entry(frame_dir, width=60)
entry_directorio.pack(side=tk.LEFT, padx=5)
if "directorio" in config:
    entry_directorio.insert(0, config["directorio"])
boton_examinar = tk.Button(frame_dir, text="Examinar", command=seleccionar_directorio)
boton_examinar.pack(side=tk.LEFT)

label_puerto = tk.Label(ventana, text="Puerto COM:")
label_puerto.pack(pady=5)
puertos = [p.device for p in serial.tools.list_ports.comports()]
combo_puerto = ttk.Combobox(ventana, values=puertos, width=25)
combo_puerto.set(config.get("puerto", puertos[0] if puertos else ""))
combo_puerto.pack()

label_baudios = tk.Label(ventana, text="Velocidad (baudios):")
label_baudios.pack(pady=5)
baud_options = ["4800", "9600", "19200", "38400", "57600", "115200"]
combo_baudios = ttk.Combobox(ventana, values=baud_options, width=25)
combo_baudios.set(config.get("baudios", "9600"))
combo_baudios.pack()

label_modelo = tk.Label(ventana, text="Modelo de radio:")
label_modelo.pack(pady=5)
combo_modelo = ttk.Combobox(ventana, width=50)
combo_modelo.pack(pady=5)

frame_tcp = tk.Frame(ventana)
frame_tcp.pack(pady=5)
tk.Label(frame_tcp, text="IP de escucha:").grid(row=0, column=0, padx=5, sticky="e")
entry_tcp_host = tk.Entry(frame_tcp, width=20)
entry_tcp_host.grid(row=0, column=1, padx=5)
entry_tcp_host.insert(0, config.get("tcp_host", DEFAULT_TCP_HOST))
tk.Label(frame_tcp, text="Puerto TCP:").grid(row=0, column=2, padx=5, sticky="e")
entry_tcp_port = tk.Entry(frame_tcp, width=10)
entry_tcp_port.grid(row=0, column=3, padx=5)
entry_tcp_port.insert(0, config.get("tcp_port", DEFAULT_TCP_PORT))

boton_ejecutar = tk.Button(
    ventana,
    text="Ejecutar rigctld",
    bg="#d9534f",
    fg="white",
    font=("Arial", 11, "bold"),
    command=ejecutar_o_detener,
)
boton_ejecutar.pack(pady=15)

frame_terminal = tk.LabelFrame(ventana, text="Consola de rigctld", padx=5, pady=5)
frame_terminal.pack(padx=10, pady=10, fill="both", expand=True)
text_terminal = tk.Text(
    frame_terminal,
    wrap="word",
    height=14,
    bg="#111",
    fg="#0f0",
    insertbackground="white",
)
text_terminal.pack(fill="both", expand=True)
scroll = tk.Scrollbar(frame_terminal, command=text_terminal.yview)
scroll.pack(side="right", fill="y")
text_terminal.config(yscrollcommand=scroll.set)

estado_label = tk.Label(ventana, text="rigctld detenido", fg="gray", font=("Arial", 9))
estado_label.pack(pady=5)
info_label = tk.Label(
    ventana,
    text="Acuantico Power - Hamlib Launcher v1.1",
    fg="gray",
    font=("Arial", 8),
)
info_label.pack(side=tk.BOTTOM, pady=5)

if "directorio" in config and os.path.exists(config.get("directorio", "")):
    actualizar_modelos()
    if "modelo_nombre" in config:
        combo_modelo.set(config["modelo_nombre"])

ventana.mainloop()
