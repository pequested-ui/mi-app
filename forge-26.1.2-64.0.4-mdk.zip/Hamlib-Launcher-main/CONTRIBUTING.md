﻿# Contributing

Thank you for considering a contribution to Hamlib Launcher! The guidelines below
help keep the project consistent and easy to maintain.

## Bug reports
- Provide clear reproduction steps and expected vs actual behaviour.
- Include the contents of the embedded console if relevant.
- Mention Windows version, Hamlib version and Python version (if running from source).

## Feature requests
- Open an issue describing the problem you want to solve before submitting a PR.
- Share mockups or screenshots if the change affects the UI.

## Development workflow
1. Create a feature branch from `main`.
2. Install dependencies using `python -m pip install -r requirements.txt`.
3. Run `python -m compileall hamlib_launcher.py` to ensure there are no syntax errors.
4. Test the GUI manually (launch and stop `rigctld`).
5. Update documentation (`README.md`, `README_EXE.md`, `CHANGELOG.md`) when behaviour changes.
6. Submit a pull request summarising the changes and testing performed.

## Coding style
- Target Python 3.10+ features only when available on mac/win envs.
- Follow PEP 8; keep functions concise and favour descriptive variable names.
- UI strings remain in Spanish to match the existing interface.
- Keep comments short and only when the code is not self-explanatory.

## Building executables
- Use `pyinstaller --onefile --noconsole --name "HamlibLauncher" --icon launcher.ico hamlib_launcher.py`.
- Do not commit `build/`, `dist/`, the `.spec` cache or generated `.exe` files.

## License
By contributing you agree that your contributions will be licensed under the
MIT License that covers this repository.
