﻿# Hamlib Launcher (.exe)

This guide focuses on the PyInstaller build of Hamlib Launcher for Windows.

## Package contents
- `HamlibLauncher.exe` – standalone application produced by PyInstaller.
- `launcher.ico` – application icon (already embedded but keep it for references or shortcuts).
- `README_EXE.md` – this file.
- `LICENSE`, `CHANGELOG.md` – legal and release information.

`config.json` is created automatically on the first run.

## Minimum requirements
- Windows 10 or 11 (64-bit).
- Hamlib binaries (`rigctl.exe`, `rigctld.exe`). Place them in a reachable directory.
- Serial drivers for your radio.

## Installation
1. Copy the contents of the PyInstaller `dist/HamlibLauncher/` folder to a desired location (e.g. `C:\Apps\HamlibLauncher`).
2. Optionally create a desktop shortcut to `HamlibLauncher.exe`.
3. Keep `launcher.ico` nearby if you want the shortcut to display the brand icon.

## Usage
1. Run `HamlibLauncher.exe`.
2. Choose the Hamlib directory containing `rigctld.exe`.
3. Select serial port, baud rate and radio model.
4. Confirm or edit the listening IP/port (defaults: `localhost:4532`).
5. Click **Ejecutar rigctld**. Output appears in the embedded console.
6. Stop the service with **Detener rigctld** or by closing the window – both send Ctrl+C to the daemon.

## Troubleshooting
- **Executable does not start** – check Windows SmartScreen; the build is unsigned.
- **No COM ports listed** – plug the device and relaunch; ensure drivers are installed.
- **`rigctld` refuses to launch** – confirm the binary exists in the chosen folder and no other instance is using the same TCP port.

## Updates
See `CHANGELOG.md` for the latest release notes. Replace the entire folder when deploying a new build.

## License
Hamlib Launcher is released under the MIT License. Hamlib itself is covered by its own license.
