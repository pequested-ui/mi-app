﻿# Changelog

All notable changes to this project are documented in this file.
The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project adheres to Semantic Versioning.

## [Unreleased]

## [1.1] - 2025-10-11
### Added
- TCP address and port configuration fields with default `localhost:4532`.
- Window title/footer updated to display the 1.1 version number.
- Download link for signed/ready builds hosted at https://acuanticopower.com/hamlib-launcher-rigctld-sin-comandos/

### Changed
- Layout spacing adjustments to fit the new network configuration section.